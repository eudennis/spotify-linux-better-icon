BEFORE YOU INSTALL THIS:

1. Install spotify for linux (Native, not wine.)
2. You must move the file spotify_icon.png to your ~/.config/spotify folder. 

TO INSTALL

Install the .desktop file with the command:

desktop-file-install /path/to/spotify.desktop

