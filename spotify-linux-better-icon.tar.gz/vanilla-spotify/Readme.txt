This has only been tested on UBUNTU 12.04!!!

First, make sure you've installed the NATIVE spotify client for linux.

Second, make sure you've moved the spotify_icon.png file to the:

  ~/.config/spotify/

folder.

Then:

Install the .desktop file with the command:

desktop-file-install /path/to/spotify.desktop

